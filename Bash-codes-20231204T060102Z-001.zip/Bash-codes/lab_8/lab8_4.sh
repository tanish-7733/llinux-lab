#!/bin/bash

echo "Current date and time: $(date)"

echo "Logged-in users:"
who

echo "System uptime:"
uptime
