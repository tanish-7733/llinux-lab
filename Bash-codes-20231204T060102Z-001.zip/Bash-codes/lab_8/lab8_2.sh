#!/bin/bash
echo "Enter a string: "
read string

length=${#string}
echo "The length of the string is $length."

echo "Enter another string: "
read another_string

echo "The concatenated string is $concatenated_string."

echo "Enter a string to compare with the original string: "
read comparison_string
if [ "$string" = "$comparison_string" ]
then
echo "The strings are equal."
else
echo "The strings are not equal."
fi
