#!/bin/bash
echo "Enter the filename: "
read filename
if [ -r "$filename" ]
then
echo "$filename is readable."
fi
if [ -w "$filename" ]
then
echo "$filename is writable."
fi
if [ -x "$filename" ]
then
echo "$filename is executable."
fi
