echo "Enter Number"
read num
sum=0
rem=0
item=$num
while [ $item -ne 0 ]
do
rem=`expr $item % 10`
sum=`expr $sum + $rem`
item=`expr $item / 10`
done 

echo "The sum of the digits is $sum"
