#!/bin/bash
echo "Enter a sentence: "
read sentence
# Split the sentence into words
for word in $sentence
do
echo "$word"
done
