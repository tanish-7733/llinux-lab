#!/bin/bash
echo "Enter a string: "
read string
# Reverse the string
reverse=$(echo "$string" | rev)
if [ "$string" = "$reverse" ]
then
echo "$string is a palindrome."
else
echo "$string is not a palindrome."
fi
