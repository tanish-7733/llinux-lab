#!/bin/bash

echo "Enter a string : "
read input

x=$(echo "$input"|rev)

echo "The reversed string is $x"
