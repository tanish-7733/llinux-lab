#!/bin/bash

echo "Enter a string : "
read input

length=${#input}

echo "The length is : $length"
