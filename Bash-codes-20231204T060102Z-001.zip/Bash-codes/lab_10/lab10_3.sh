echo "Enter the first string : "
read first

echo "Enter the second string "
read second

third="${first}${second}"

echo "after concatination $third"
