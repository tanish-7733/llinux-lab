#!/bin/bash

fact() {

fact=1
n=$1
while [ $n -ne 0 ] 
do

fact=$((fact*n))
n=$((n-1))

done

echo $fact

}

echo "enter number"
read num
fact $num

